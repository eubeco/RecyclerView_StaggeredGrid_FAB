package com.example.recyclerview_staggeredgrid_fab

class Tarjeta (val Texto  :  Int) {
}